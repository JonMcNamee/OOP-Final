﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Martin_McNamee_Final
{
    public class User
    {
        public string UserID { get; set; }

        public string Password { get; set; }

        public string Name { get; set; }

        public bool Access { get; set; }

        //default constructor
        public User()
        {

        }

        //custom constructor
        public User(string inUser, string inPassword, string inName, bool inAccess)
        {
            UserID = inUser;
            Password = inPassword;
            Name = inName;
            Access = inAccess;
        }
    }
}
