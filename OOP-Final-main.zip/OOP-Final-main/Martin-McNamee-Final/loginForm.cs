﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Martin_McNamee_Final
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            StreamReader userFile = new StreamReader(@"c:\files\users.txt");

            List<string> userList = new List<string>();

            while (!userFile.EndOfStream)
            {
                userList.Add(userFile.ReadLine());
            }

            string userInput = txtUsername.Text;
            string passInput = txtPassword.Text;

            for(int i = 0; i < userList.Count; i++)
            {
                string[] userFields = userList[i].Split(',');
                string username = userFields[0];
                string password = userFields[1];
                string access = userFields[3];

                if(username == userInput && password == passInput)
                {
                    MessageBox.Show("Login Successful!", "OOP Final, Jon McNamee, Jonah Martin");

                    if(access == "false")
                    {
                        frmCustomer custForm = new frmCustomer();
                        this.Hide();
                        custForm.ShowDialog();
                        this.Close();

                    }
                    else if (access == "true")
                    {
                        frmAdmin adminForm = new frmAdmin();
                        this.Hide();
                        adminForm.ShowDialog();
                        this.Close();

                    }


                }
            }
        }
    }
}
