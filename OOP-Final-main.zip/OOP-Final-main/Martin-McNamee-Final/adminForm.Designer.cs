﻿namespace Martin_McNamee_Final
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstProductsDisplay = new System.Windows.Forms.ListBox();
            this.lblTitle = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtProductCode = new System.Windows.Forms.TextBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.radAddProduct = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radUpdateProduct = new System.Windows.Forms.RadioButton();
            this.radChicken = new System.Windows.Forms.RadioButton();
            this.radBeef = new System.Windows.Forms.RadioButton();
            this.radVegetarian = new System.Windows.Forms.RadioButton();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnAddUpdate = new System.Windows.Forms.Button();
            this.picLogo = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // lstProductsDisplay
            // 
            this.lstProductsDisplay.FormattingEnabled = true;
            this.lstProductsDisplay.Location = new System.Drawing.Point(47, 88);
            this.lstProductsDisplay.Name = "lstProductsDisplay";
            this.lstProductsDisplay.Size = new System.Drawing.Size(220, 173);
            this.lstProductsDisplay.TabIndex = 0;
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Algerian", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.lblTitle.Location = new System.Drawing.Point(182, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(239, 30);
            this.lblTitle.TabIndex = 9;
            this.lblTitle.Text = "Souperior Soups";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(44, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Items In Stock:";
            // 
            // txtProductCode
            // 
            this.txtProductCode.Location = new System.Drawing.Point(393, 168);
            this.txtProductCode.Name = "txtProductCode";
            this.txtProductCode.Size = new System.Drawing.Size(100, 20);
            this.txtProductCode.TabIndex = 2;
            // 
            // txtProductName
            // 
            this.txtProductName.Location = new System.Drawing.Point(393, 194);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(100, 20);
            this.txtProductName.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(312, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Product Code:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(312, 199);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Product Name:";
            // 
            // txtQuantity
            // 
            this.txtQuantity.Location = new System.Drawing.Point(393, 220);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(100, 20);
            this.txtQuantity.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(312, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Quantity:";
            // 
            // radAddProduct
            // 
            this.radAddProduct.AutoSize = true;
            this.radAddProduct.Location = new System.Drawing.Point(15, 19);
            this.radAddProduct.Name = "radAddProduct";
            this.radAddProduct.Size = new System.Drawing.Size(84, 17);
            this.radAddProduct.TabIndex = 0;
            this.radAddProduct.TabStop = true;
            this.radAddProduct.Text = "Add Product";
            this.radAddProduct.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radUpdateProduct);
            this.groupBox1.Controls.Add(this.radAddProduct);
            this.groupBox1.Location = new System.Drawing.Point(315, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(178, 67);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Edit Type";
            // 
            // radUpdateProduct
            // 
            this.radUpdateProduct.AutoSize = true;
            this.radUpdateProduct.Location = new System.Drawing.Point(15, 42);
            this.radUpdateProduct.Name = "radUpdateProduct";
            this.radUpdateProduct.Size = new System.Drawing.Size(100, 17);
            this.radUpdateProduct.TabIndex = 1;
            this.radUpdateProduct.TabStop = true;
            this.radUpdateProduct.Text = "Update Product";
            this.radUpdateProduct.UseVisualStyleBackColor = true;
            // 
            // radChicken
            // 
            this.radChicken.AutoSize = true;
            this.radChicken.Location = new System.Drawing.Point(6, 19);
            this.radChicken.Name = "radChicken";
            this.radChicken.Size = new System.Drawing.Size(64, 17);
            this.radChicken.TabIndex = 0;
            this.radChicken.TabStop = true;
            this.radChicken.Text = "Chicken";
            this.radChicken.UseVisualStyleBackColor = true;
            // 
            // radBeef
            // 
            this.radBeef.AutoSize = true;
            this.radBeef.Location = new System.Drawing.Point(6, 42);
            this.radBeef.Name = "radBeef";
            this.radBeef.Size = new System.Drawing.Size(47, 17);
            this.radBeef.TabIndex = 1;
            this.radBeef.TabStop = true;
            this.radBeef.Text = "Beef";
            this.radBeef.UseVisualStyleBackColor = true;
            // 
            // radVegetarian
            // 
            this.radVegetarian.AutoSize = true;
            this.radVegetarian.Location = new System.Drawing.Point(6, 65);
            this.radVegetarian.Name = "radVegetarian";
            this.radVegetarian.Size = new System.Drawing.Size(76, 17);
            this.radVegetarian.TabIndex = 2;
            this.radVegetarian.TabStop = true;
            this.radVegetarian.Text = "Vegetarian";
            this.radVegetarian.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radChicken);
            this.groupBox2.Controls.Add(this.radVegetarian);
            this.groupBox2.Controls.Add(this.radBeef);
            this.groupBox2.Location = new System.Drawing.Point(499, 158);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(100, 93);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Meat";
            // 
            // btnAddUpdate
            // 
            this.btnAddUpdate.Location = new System.Drawing.Point(341, 257);
            this.btnAddUpdate.Name = "btnAddUpdate";
            this.btnAddUpdate.Size = new System.Drawing.Size(124, 40);
            this.btnAddUpdate.TabIndex = 6;
            this.btnAddUpdate.Text = "Add or Update &Product";
            this.btnAddUpdate.UseVisualStyleBackColor = true;
            // 
            // picLogo
            // 
            this.picLogo.Image = global::Martin_McNamee_Final.Properties.Resources.souplogo;
            this.picLogo.Location = new System.Drawing.Point(523, 12);
            this.picLogo.Name = "picLogo";
            this.picLogo.Size = new System.Drawing.Size(76, 66);
            this.picLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picLogo.TabIndex = 15;
            this.picLogo.TabStop = false;
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.NavajoWhite;
            this.ClientSize = new System.Drawing.Size(611, 309);
            this.Controls.Add(this.btnAddUpdate);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtQuantity);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtProductName);
            this.Controls.Add(this.txtProductCode);
            this.Controls.Add(this.picLogo);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lstProductsDisplay);
            this.Name = "frmAdmin";
            this.Text = "Jonah Martin, Jon McNamee - Admin Screen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picLogo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstProductsDisplay;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox picLogo;
        private System.Windows.Forms.TextBox txtProductCode;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton radAddProduct;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radUpdateProduct;
        private System.Windows.Forms.RadioButton radChicken;
        private System.Windows.Forms.RadioButton radBeef;
        private System.Windows.Forms.RadioButton radVegetarian;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btnAddUpdate;
    }
}